﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using fractal.newClass;
namespace Fracture_Identification
{
    class FaultDataClass
    {
        public string FaultName;
       public List<List<data3>> DataList = new List<List<data3>>();
       public List<bool> bDisplay = new List<bool>();
    }
}
