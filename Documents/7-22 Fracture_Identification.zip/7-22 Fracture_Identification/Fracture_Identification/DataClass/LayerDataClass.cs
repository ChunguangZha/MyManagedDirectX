﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using fractal.newClass;

namespace Fracture_Identification
{
    class LayerDataClass
    {
        public string layerName;        
        public List<data3> Datalist = new List<data3>();
        
    }
}
