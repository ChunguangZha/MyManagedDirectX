﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fracture_Identification
{
    class WellDataClass
    {
        public string WellName;
        public List<DataStr4> DataList = new List<DataStr4>();
        public List<bool> bDisplay = new List<bool>();
    }
}
