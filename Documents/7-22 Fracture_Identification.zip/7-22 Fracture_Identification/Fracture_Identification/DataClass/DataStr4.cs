﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fracture_Identification
{
    struct DataStr4
    {
        private double x;
        private double y;
        private string z;
        private double w;
        public double xx
        {
            get { return x; }
            set { x = value; }
        }
        public double yy
        {
            get { return y; }
            set { y = value; }
        }
        public string zz
        {
            get { return z; }
            set { z = value; }
        }
        public double ww
        {
            get { return w; }
            set { w = value; }
        }

        //private bool display;

        //public bool Display
        //{
        //    get { return display; }
        //    set { display = value; }
        //}
    }
}
